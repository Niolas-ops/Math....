import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

/**
 * MathLab - Virtual Math Laboratory
 * Full-Screen Infinite Grid (Desmos-style), Interactive Floating Panels,
 * Draggable Shapes, Dynamic Dimension Inputs & Real-Time Mathematical Properties
 */

// --- Subject Laboratories Configuration (Preserved for Non-Geometry Pages) ---
const LABS_CONFIG = {
  algebra: {
    title: 'Algebra',
    badge: 'Under Construction',
    subtitle: 'Coordinate Geometry, Functions & Linear Systems',
    icon: 'f(x)',
    tag: 'Algebra Laboratory',
    themeColor: '#059669',
    desc: 'Explore polynomial curves, quadratic roots, vertex transformations, and systems of linear equations through interactive graphs.',
    modules: [
      { name: 'Quadratic Parabola Explorer', desc: 'Drag vertex and focus points to explore y = a(x - h)² + k in real-time', status: 'In Design' },
      { name: 'Linear Systems Solver', desc: 'Simultaneously plot intersecting lines with matrix determinant feedback', status: 'Queued' },
      { name: 'Polynomial Roots Visualizer', desc: 'Interactive complex roots and multiplicity factoring manipulatives', status: 'Queued' },
      { name: 'Rational Function Asymptote Map', desc: 'Observe vertical, horizontal, and slant asymptotes dynamically', status: 'Planned' }
    ],
    bgSvg: `<svg viewBox="0 0 600 400" fill="none" xmlns="http://www.w3.org/2000/svg" class="faint-bg-svg">
      <defs>
        <pattern id="algFaintGrid" width="30" height="30" patternUnits="userSpaceOnUse">
          <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(5, 150, 105, 0.08)" stroke-width="1" />
        </pattern>
      </defs>
      <rect width="600" height="400" fill="url(#algFaintGrid)" />
      <line x1="300" y1="0" x2="300" y2="400" stroke="rgba(5, 150, 105, 0.18)" stroke-width="2" />
      <line x1="0" y1="200" x2="600" y2="200" stroke="rgba(5, 150, 105, 0.18)" stroke-width="2" />
      <path d="M 120 40 Q 300 360 480 40" fill="none" stroke="rgba(5, 150, 105, 0.22)" stroke-width="4" />
      <text x="320" y="50" font-size="28" font-family="'Times New Roman', serif" font-style="italic" fill="rgba(5, 150, 105, 0.12)">x² + 2x = 8</text>
      <text x="80" y="180" font-size="24" font-family="'Times New Roman', serif" font-style="italic" fill="rgba(5, 150, 105, 0.12)">f(x) = ax² + bx + c</text>
      <text x="360" y="320" font-size="22" font-family="'Times New Roman', serif" font-style="italic" fill="rgba(5, 150, 105, 0.12)">y = mx + b</text>
    </svg>`
  },
  trigonometry: {
    title: 'Trigonometry',
    badge: 'Under Construction',
    subtitle: 'Unit Circle, Wave Harmonizers & Angle Ratios',
    icon: 'sin θ',
    tag: 'Trigonometry Laboratory',
    themeColor: '#ea580c',
    desc: 'Interact with the dynamic unit circle, observe sine and cosine wave generation in real-time, and solve triangle ratios visually.',
    modules: [
      { name: 'Dynamic Unit Circle Explorer', desc: 'Interactive angle ray dragging with real-time sin, cos, and tan projections', status: 'In Design' },
      { name: 'Continuous Sine Wave Generator', desc: 'Rotating phasors unfolding into continuous time-domain sine waves', status: 'Queued' },
      { name: 'Trigonometric Identities Proofs', desc: 'Geometric rearrangement proofs for sin²θ + cos²θ = 1 and sum formulas', status: 'Queued' },
      { name: 'Fourier Harmonic Synthesizer', desc: 'Summing sinusoidal harmonics to create square, sawtooth, and audio waves', status: 'Planned' }
    ],
    bgSvg: `<svg viewBox="0 0 600 400" fill="none" xmlns="http://www.w3.org/2000/svg" class="faint-bg-svg">
      <defs>
        <pattern id="trigFaintGrid" width="30" height="30" patternUnits="userSpaceOnUse">
          <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(234, 88, 12, 0.08)" stroke-width="1" />
        </pattern>
      </defs>
      <rect width="600" height="400" fill="url(#trigFaintGrid)" />
      <circle cx="180" cy="200" r="120" fill="none" stroke="rgba(234, 88, 12, 0.18)" stroke-width="3" />
      <line x1="60" y1="200" x2="600" y2="200" stroke="rgba(234, 88, 12, 0.15)" stroke-width="2" />
      <line x1="180" y1="60" x2="180" y2="340" stroke="rgba(234, 88, 12, 0.15)" stroke-width="2" />
      <path d="M 180 200 C 240 80, 300 320, 360 200 C 420 80, 480 320, 540 200" fill="none" stroke="rgba(234, 88, 12, 0.22)" stroke-width="4" />
      <text x="380" y="100" font-size="28" font-family="'Times New Roman', serif" font-style="italic" fill="rgba(234, 88, 12, 0.12)">sin²θ + cos²θ = 1</text>
      <text x="60" y="100" font-size="26" font-family="'Times New Roman', serif" font-style="italic" fill="rgba(234, 88, 12, 0.12)">tan θ = sin θ / cos θ</text>
    </svg>`
  },
  calculus: {
    title: 'Calculus',
    badge: 'Under Construction',
    subtitle: 'Derivatives, Tangent Slopes & Riemann Integrals',
    icon: '∫ dx',
    tag: 'Calculus Laboratory',
    themeColor: '#9333ea',
    desc: 'Watch limits converge, explore tangent line slopes dynamically as derivatives, and compute Riemann sums under curves visually.',
    modules: [
      { name: 'Tangent Slope & Derivative Zoom', desc: 'Magnify curves to infinitesimal linear secants converging to dy/dx', status: 'In Design' },
      { name: 'Riemann Sum Area Integrator', desc: 'Interactive rectangle partitions (left, midpoint, trapezoid) converging to ∫', status: 'Queued' },
      { name: 'Fundamental Theorem Playground', desc: 'Visual connection between rate-of-change accumulation and curve height', status: 'Queued' },
      { name: 'Taylor Series Polynomial Expander', desc: 'Dynamic polynomial degree expansion fitting arbitrary target functions', status: 'Planned' }
    ],
    bgSvg: `<svg viewBox="0 0 600 400" fill="none" xmlns="http://www.w3.org/2000/svg" class="faint-bg-svg">
      <defs>
        <pattern id="calcFaintGrid" width="30" height="30" patternUnits="userSpaceOnUse">
          <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(147, 51, 234, 0.08)" stroke-width="1" />
        </pattern>
      </defs>
      <rect width="600" height="400" fill="url(#calcFaintGrid)" />
      <line x1="80" y1="40" x2="80" y2="360" stroke="rgba(147, 51, 234, 0.15)" stroke-width="2" />
      <line x1="40" y1="320" x2="560" y2="320" stroke="rgba(147, 51, 234, 0.15)" stroke-width="2" />
      <path d="M 90 310 C 180 180, 260 280, 360 140 C 440 60, 500 200, 550 280" fill="none" stroke="rgba(147, 51, 234, 0.22)" stroke-width="4" />
      <line x1="260" y1="230" x2="460" y2="50" stroke="rgba(236, 72, 153, 0.25)" stroke-width="3" stroke-dasharray="6 4" />
      <text x="120" y="110" font-size="44" font-family="'Times New Roman', serif" fill="rgba(147, 51, 234, 0.15)">∫ f(x) dx</text>
      <text x="380" y="70" font-size="26" font-family="'Times New Roman', serif" font-style="italic" fill="rgba(147, 51, 234, 0.15)">dy/dx = lim Δx→0</text>
    </svg>`
  },
  probability: {
    title: 'Probability',
    badge: 'Under Construction',
    subtitle: 'Random Variables, Bell Curves & Monte Carlo Simulations',
    icon: 'P(X)',
    tag: 'Probability Laboratory',
    themeColor: '#e11d48',
    desc: 'Simulate dice rolls, coin flips, Poisson processes, and watch the Central Limit Theorem emerge with real-time distribution curves.',
    modules: [
      { name: 'High-speed Dice & Coin Simulator', desc: 'Simulate up to 100,000 trials with instant visual frequency histograms', status: 'In Design' },
      { name: 'Gaussian Bell Curve & Z-Score', desc: 'Interactive mean μ and standard deviation σ interval area calculators', status: 'Queued' },
      { name: 'Galton Board Physics Simulator', desc: 'Dropping pin-grid beads forming a perfect binomial bell distribution', status: 'Queued' },
      { name: 'Bayesian Inference Tree Model', desc: 'Conditional probability update calculators with tree branches and Venn diagrams', status: 'Planned' }
    ],
    bgSvg: `<svg viewBox="0 0 600 400" fill="none" xmlns="http://www.w3.org/2000/svg" class="faint-bg-svg">
      <defs>
        <pattern id="probFaintGrid" width="30" height="30" patternUnits="userSpaceOnUse">
          <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(225, 29, 72, 0.08)" stroke-width="1" />
        </pattern>
      </defs>
      <rect width="600" height="400" fill="url(#probFaintGrid)" />
      <line x1="50" y1="320" x2="550" y2="320" stroke="rgba(225, 29, 72, 0.15)" stroke-width="2" />
      <path d="M 100 320 C 200 320, 240 80, 300 80 C 360 80, 400 320, 500 320" fill="none" stroke="rgba(225, 29, 72, 0.22)" stroke-width="4" />
      <line x1="300" y1="80" x2="300" y2="320" stroke="rgba(225, 29, 72, 0.15)" stroke-width="2" stroke-dasharray="4 4" />
      <text x="290" y="65" font-size="24" font-weight="bold" fill="rgba(225, 29, 72, 0.15)">μ</text>
      <text x="80" y="160" font-size="28" font-family="'Times New Roman', serif" fill="rgba(225, 29, 72, 0.15)">P(A ∩ B) = P(A) · P(B|A)</text>
      <text x="380" y="240" font-size="26" font-family="'Times New Roman', serif" fill="rgba(225, 29, 72, 0.15)">σ = √(Σ(x - μ)² / N)</text>
    </svg>`
  }
};

// --- GEOMETRY DATA STRUCTURES ---

const SHAPES = {
  square: {
    id: 'square',
    name: 'Square',
    visible: true,
    color: '#2563eb',
    fillColor: 'rgba(37, 99, 235, 0.22)',
    strokeColor: '#2563eb',
    x: 0,
    y: 0,
    rotation: 0,
    depth: 3,
    side: 4
  },
  rectangle: {
    id: 'rectangle',
    name: 'Rectangle',
    visible: false,
    color: '#059669',
    fillColor: 'rgba(160, 185, 129, 0.22)',
    strokeColor: '#059669',
    x: 0,
    y: 0,
    rotation: 0,
    depth: 3,
    width: 2,
    length: 4
  },
  circle: {
    id: 'circle',
    name: 'Circle',
    visible: false,
    color: '#dc2626',
    fillColor: 'rgba(239, 68, 68, 0.22)',
    strokeColor: '#dc2626',
    x: 0,
    y: 0,
    rotation: 0,
    depth: 3,
    radius: 3
  },
  triangle: {
    id: 'triangle',
    name: 'Triangle',
    visible: false,
    color: '#ea580c',
    fillColor: 'rgba(249, 115, 22, 0.22)',
    strokeColor: '#ea580c',
    x: 0,
    y: 0,
    rotation: 0,
    depth: 3,
    sideA: 3,
    sideB: 4,
    sideC: 5
  },
  pentagon: {
    id: 'pentagon',
    name: 'Pentagon',
    visible: false,
    color: '#9333ea',
    fillColor: 'rgba(168, 85, 247, 0.22)',
    strokeColor: '#9333ea',
    x: 0,
    y: 0,
    rotation: 0,
    depth: 3,
    side: 3
  },
  hexagon: {
    id: 'hexagon',
    name: 'Hexagon',
    visible: false,
    color: '#0d9488',
    fillColor: 'rgba(13, 148, 136, 0.22)',
    strokeColor: '#0d9488',
    x: 0,
    y: 0,
    rotation: 0,
    depth: 3,
    side: 3
  },
  ellipse: {
    id: 'ellipse',
    name: 'Ellipse',
    visible: false,
    color: '#db2777',
    fillColor: 'rgba(219, 39, 119, 0.22)',
    strokeColor: '#db2777',
    x: 0,
    y: 0,
    rotation: 0,
    depth: 3,
    radiusX: 4,
    radiusY: 2.5
  },
  sphere: {
    id: 'sphere',
    name: 'Sphere',
    is3DOnly: true,
    visible: false,
    color: '#0284c7',
    fillColor: 'rgba(2, 132, 199, 0.25)',
    strokeColor: '#0369a1',
    x: 0,
    y: 0,
    rotation: 0,
    radius: 2.5
  },
  pyramid: {
    id: 'pyramid',
    name: 'Pyramid',
    is3DOnly: true,
    visible: false,
    color: '#d97706',
    fillColor: 'rgba(217, 119, 6, 0.25)',
    strokeColor: '#b45309',
    x: 0,
    y: 0,
    rotation: 0,
    baseSize: 4,
    height: 4
  },
  cone: {
    id: 'cone',
    name: 'Cone',
    is3DOnly: true,
    visible: false,
    color: '#16a34a',
    fillColor: 'rgba(22, 163, 74, 0.25)',
    strokeColor: '#15803d',
    x: 0,
    y: 0,
    rotation: 0,
    radius: 2.5,
    height: 4
  },
  torus: {
    id: 'torus',
    name: 'Torus / Donut',
    is3DOnly: true,
    visible: false,
    color: '#8b5cf6',
    fillColor: 'rgba(139, 92, 246, 0.25)',
    strokeColor: '#7c3aed',
    x: 0,
    y: 0,
    rotation: 0,
    radius: 3,
    tube: 1
  }
};

// Render order array (last item is drawn on top)
let renderOrder = ['ellipse', 'hexagon', 'pentagon', 'triangle', 'circle', 'rectangle', 'square', 'sphere', 'pyramid', 'cone', 'torus'];

// Active shape ID for Dimensions & Properties panels
let activeShapeId = 'square';

// 2D / 3D Mode & Extrusion State
let currentViewMode = '2d'; // '2d' | '3d'
let extrusionDepth = 3.0;

// Three.js State & Objects
let threeContainer = null;
let threeScene = null;
let threeCamera = null;
let threeRenderer = null;
let threeControls = null;
let threeAnimFrameId = null;
let threeShapeGroup = null;
let threeAxesGroup = null;
let threeGridHelper = null;
let threeRaycaster = null;
let threeMouse = null;
let threePointerDownPos = { x: 0, y: 0 };
let is3DDragging = false;
let is3DRotating = false;
let dragged3DShape = null;
let threeDragPlane = null;
let threePlaneIntersection = null;
let threeDragOffset = { x: 0, z: 0 };
let threeRotateStartAngle = 0;
let threeInitialShapeRot = 0;

// Infinite Grid Coordinate State (Desmos-like)
const gridState = {
  originX: 0,       // screen pixel X of math (0,0)
  originY: 0,       // screen pixel Y of math (0,0)
  scale: 40,        // pixels per math unit (default 40px)
  isPanning: false,
  panStartX: 0,
  panStartY: 0,
  initialOriginX: 0,
  initialOriginY: 0,
  isDraggingShape: false,
  isRotatingShape: false,
  draggedShape: null,
  shapeDragOffsetMathX: 0,
  shapeDragOffsetMathY: 0
};

// DOM References
let canvas = null;
let ctx = null;

// --- Initialize App ---
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}

function initApp() {
  initCanvas();
  initPanAndZoomEvents();
  initShapeSelectorPanel();
  initGridControls();
  initViewModeToggle();
  initHashRouting();
  renderAllPanels();
  render();
}

// --- Coordinate Conversions ---
function toScreenX(mathX) {
  return gridState.originX + mathX * gridState.scale;
}

function toScreenY(mathY) {
  return gridState.originY - mathY * gridState.scale;
}

function toMathX(screenX) {
  return (screenX - gridState.originX) / gridState.scale;
}

function toMathY(screenY) {
  return (gridState.originY - screenY) / gridState.scale;
}

function getShapeHalfExtents(shape) {
  let halfW = 20;
  let halfH = 20;
  if (!shape) return { halfW, halfH };

  if (shape.id === 'square') {
    halfW = (shape.side * gridState.scale) / 2 + 6;
    halfH = halfW;
  } else if (shape.id === 'rectangle') {
    halfW = (shape.width * gridState.scale) / 2 + 6;
    halfH = (shape.length * gridState.scale) / 2 + 6;
  } else if (shape.id === 'circle') {
    halfW = (shape.radius * gridState.scale) + 6;
    halfH = halfW;
  } else if (shape.id === 'ellipse') {
    halfW = (shape.radiusX * gridState.scale) + 6;
    halfH = (shape.radiusY * gridState.scale) + 6;
  } else {
    halfW = (shape.side * gridState.scale) + 8;
    halfH = halfW;
  }
  return { halfW, halfH };
}

function getRotationHandleScreenCoords(shape) {
  if (!shape) return { x: 0, y: 0 };
  const { halfH } = getShapeHalfExtents(shape);
  const stem = 24;
  const dist = halfH + stem;
  const sx = toScreenX(shape.x);
  const sy = toScreenY(shape.y);
  const rot = shape.rotation || 0;
  return {
    x: sx + Math.sin(rot) * dist,
    y: sy - Math.cos(rot) * dist
  };
}

function getShapeBoundingRadius(shape) {
  if (!shape) return 2.0;
  switch (shape.id) {
    case 'square': return (shape.side * Math.SQRT2) / 2;
    case 'rectangle': return Math.hypot(shape.width, shape.length) / 2;
    case 'circle': return shape.radius;
    case 'ellipse': return Math.max(shape.radiusX, shape.radiusY);
    case 'triangle': return Math.max(shape.sideA, shape.sideB, shape.sideC) / 1.5;
    case 'pentagon': return shape.side * 0.85;
    case 'hexagon': return shape.side;
    case 'sphere': return shape.radius;
    case 'pyramid': return Math.max(shape.baseSize / 1.4, shape.height);
    case 'cone': return Math.max(shape.radius, shape.height);
    case 'torus': return shape.radius + shape.tube;
    default: return 2.5;
  }
}

// --- Canvas Setup & Resizing ---
function initCanvas() {
  canvas = document.getElementById('geometryCanvas');
  if (!canvas) return;
  ctx = canvas.getContext('2d');
  resizeCanvas();
  window.addEventListener('resize', onWindowResize);
}

function resizeCanvas() {
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  const width = window.innerWidth;
  const height = window.innerHeight;

  canvas.width = Math.floor(width * dpr);
  canvas.height = Math.floor(height * dpr);
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;

  if (ctx) {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  // Initialize origin to screen center if not set yet
  if (gridState.originX === 0 && gridState.originY === 0) {
    gridState.originX = width / 2;
    gridState.originY = height / 2;
  }
}

function onWindowResize() {
  const oldWidth = canvas ? canvas.clientWidth : window.innerWidth;
  const oldHeight = canvas ? canvas.clientHeight : window.innerHeight;
  resizeCanvas();
  const newWidth = window.innerWidth;
  const newHeight = window.innerHeight;

  // Preserve relative origin position on resize
  if (oldWidth > 0 && oldHeight > 0) {
    const relX = gridState.originX / oldWidth;
    const relY = gridState.originY / oldHeight;
    gridState.originX = relX * newWidth;
    gridState.originY = relY * newHeight;
  }
  render();
}

// --- Infinite Grid Pan & Zoom Events ---
function initPanAndZoomEvents() {
  if (!canvas) return;

  // Mouse Wheel Zoom centered on cursor
  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;

    const mathX = toMathX(sx);
    const mathY = toMathY(sy);

    // Zoom factor: 1.12 for zooming in, 1/1.12 for zooming out
    const zoomFactor = e.deltaY < 0 ? 1.12 : (1 / 1.12);
    const newScale = Math.max(0.0001, Math.min(20000, gridState.scale * zoomFactor));

    // Keep point under cursor stationary
    gridState.originX = sx - mathX * newScale;
    gridState.originY = sy + mathY * newScale;
    gridState.scale = newScale;

    render();
  }, { passive: false });

  // Mouse Down
  canvas.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return; // Only left click
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const mx = toMathX(sx);
    const my = toMathY(sy);

    // 1. Check if clicked on rotation handle of the active shape
    const activeShape = activeShapeId ? SHAPES[activeShapeId] : null;
    if (activeShape && activeShape.visible && !activeShape.is3DOnly) {
      const hPos = getRotationHandleScreenCoords(activeShape);
      if (Math.hypot(sx - hPos.x, sy - hPos.y) <= 14) {
        gridState.isRotatingShape = true;
        gridState.draggedShape = activeShape;
        canvas.classList.add('rotating-shape');
        return;
      }
    }

    // 2. Check if clicked on a visible shape (top-most first)
    const hitShape = getShapeAtMathCoords(mx, my);

    if (hitShape) {
      bringShapeToFront(hitShape.id);
      setActiveShape(hitShape.id);

      if (e.shiftKey) {
        gridState.isRotatingShape = true;
        gridState.draggedShape = hitShape;
        canvas.classList.add('rotating-shape');
      } else {
        gridState.isDraggingShape = true;
        gridState.draggedShape = hitShape;
        gridState.shapeDragOffsetMathX = mx - hitShape.x;
        gridState.shapeDragOffsetMathY = my - hitShape.y;
        canvas.classList.add('dragging-shape');
      }
      render();
      renderAllPanels();
    } else {
      // Background pan
      gridState.isPanning = true;
      gridState.panStartX = sx;
      gridState.panStartY = sy;
      gridState.initialOriginX = gridState.originX;
      gridState.initialOriginY = gridState.originY;
      canvas.classList.add('panning');
    }
  });

  // Mouse Move
  window.addEventListener('mousemove', (e) => {
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const mx = toMathX(sx);
    const my = toMathY(sy);

    // Update cursor readout
    updateCoordsReadout(mx, my);

    if (gridState.isRotatingShape && gridState.draggedShape) {
      const shape = gridState.draggedShape;
      const centerSx = toScreenX(shape.x);
      const centerSy = toScreenY(shape.y);
      const angle = Math.atan2(sx - centerSx, -(sy - centerSy));
      shape.rotation = angle;
      canvas.style.cursor = 'crosshair';
      render();
      renderPropertiesPanel();
    } else if (gridState.isDraggingShape && gridState.draggedShape) {
      gridState.draggedShape.x = mx - gridState.shapeDragOffsetMathX;
      gridState.draggedShape.y = my - gridState.shapeDragOffsetMathY;
      canvas.style.cursor = 'move';
      render();
      updateDimensionsPanelValues();
    } else if (gridState.isPanning) {
      const dx = sx - gridState.panStartX;
      const dy = sy - gridState.panStartY;
      gridState.originX = gridState.initialOriginX + dx;
      gridState.originY = gridState.initialOriginY + dy;
      render();
    } else {
      // Hover feedback
      const activeShape = activeShapeId ? SHAPES[activeShapeId] : null;
      if (activeShape && activeShape.visible && !activeShape.is3DOnly) {
        const hPos = getRotationHandleScreenCoords(activeShape);
        if (Math.hypot(sx - hPos.x, sy - hPos.y) <= 14) {
          canvas.style.cursor = 'crosshair';
          return;
        }
      }
      const hitShape = getShapeAtMathCoords(mx, my);
      if (hitShape) {
        canvas.style.cursor = e.shiftKey ? 'crosshair' : 'move';
      } else {
        canvas.style.cursor = 'grab';
      }
    }
  });

  // Mouse Up
  window.addEventListener('mouseup', () => {
    if (gridState.isDraggingShape) {
      gridState.isDraggingShape = false;
      gridState.draggedShape = null;
      if (canvas) canvas.classList.remove('dragging-shape');
    }
    if (gridState.isRotatingShape) {
      gridState.isRotatingShape = false;
      gridState.draggedShape = null;
      if (canvas) canvas.classList.remove('rotating-shape');
    }
    if (gridState.isPanning) {
      gridState.isPanning = false;
      if (canvas) canvas.classList.remove('panning');
    }
  });

  // Touch Support
  let touchStartDist = 0;
  let touchStartScale = 40;

  canvas.addEventListener('touchstart', (e) => {
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      const rect = canvas.getBoundingClientRect();
      const sx = touch.clientX - rect.left;
      const sy = touch.clientY - rect.top;
      const mx = toMathX(sx);
      const my = toMathY(sy);

      const activeShape = activeShapeId ? SHAPES[activeShapeId] : null;
      if (activeShape && activeShape.visible && !activeShape.is3DOnly) {
        const hPos = getRotationHandleScreenCoords(activeShape);
        if (Math.hypot(sx - hPos.x, sy - hPos.y) <= 22) {
          gridState.isRotatingShape = true;
          gridState.draggedShape = activeShape;
          return;
        }
      }

      const hitShape = getShapeAtMathCoords(mx, my);
      if (hitShape) {
        gridState.isDraggingShape = true;
        gridState.draggedShape = hitShape;
        gridState.shapeDragOffsetMathX = mx - hitShape.x;
        gridState.shapeDragOffsetMathY = my - hitShape.y;
        bringShapeToFront(hitShape.id);
        setActiveShape(hitShape.id);
        render();
        renderAllPanels();
      } else {
        gridState.isPanning = true;
        gridState.panStartX = sx;
        gridState.panStartY = sy;
        gridState.initialOriginX = gridState.originX;
        gridState.initialOriginY = gridState.originY;
      }
    } else if (e.touches.length === 2) {
      // Pinch to zoom
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      touchStartDist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
      touchStartScale = gridState.scale;
    }
    e.preventDefault();
  }, { passive: false });

  window.addEventListener('touchmove', (e) => {
    if (!canvas) return;
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      const rect = canvas.getBoundingClientRect();
      const sx = touch.clientX - rect.left;
      const sy = touch.clientY - rect.top;
      const mx = toMathX(sx);
      const my = toMathY(sy);

      if (gridState.isRotatingShape && gridState.draggedShape) {
        const shape = gridState.draggedShape;
        const centerSx = toScreenX(shape.x);
        const centerSy = toScreenY(shape.y);
        shape.rotation = Math.atan2(sx - centerSx, -(sy - centerSy));
        render();
        renderPropertiesPanel();
      } else if (gridState.isDraggingShape && gridState.draggedShape) {
        gridState.draggedShape.x = mx - gridState.shapeDragOffsetMathX;
        gridState.draggedShape.y = my - gridState.shapeDragOffsetMathY;
        render();
        updateDimensionsPanelValues();
      } else if (gridState.isPanning) {
        gridState.originX = gridState.initialOriginX + (sx - gridState.panStartX);
        gridState.originY = gridState.initialOriginY + (sy - gridState.panStartY);
        render();
      }
    } else if (e.touches.length === 2) {
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const currentDist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
      if (touchStartDist > 0) {
        const factor = currentDist / touchStartDist;
        const rect = canvas.getBoundingClientRect();
        const midX = (t1.clientX + t2.clientX) / 2 - rect.left;
        const midY = (t1.clientY + t2.clientY) / 2 - rect.top;
        const mx = toMathX(midX);
        const my = toMathY(midY);
        const newScale = Math.max(0.0001, Math.min(20000, touchStartScale * factor));

        gridState.originX = midX - mx * newScale;
        gridState.originY = midY + my * newScale;
        gridState.scale = newScale;
        render();
      }
    }
  }, { passive: false });

  window.addEventListener('touchend', () => {
    gridState.isDraggingShape = false;
    gridState.isRotatingShape = false;
    gridState.draggedShape = null;
    gridState.isPanning = false;
    touchStartDist = 0;
  });
}

function updateCoordsReadout(mx, my) {
  const readout = document.getElementById('gridCoordsReadout');
  if (readout) {
    const signX = mx >= 0 ? '+' : '';
    const signY = my >= 0 ? '+' : '';
    readout.textContent = `(${signX}${mx.toFixed(2)}, ${signY}${my.toFixed(2)})`;
  }
}

// --- Shape Selector Panel Controls (Top-Left) ---
function initShapeSelectorPanel() {
  const shapeIds = Object.keys(SHAPES);
  shapeIds.forEach((id) => {
    const checkbox = document.getElementById(`check_${id}`);
    const itemLabel = document.getElementById(`shapeItem_${id}`);

    if (checkbox) {
      checkbox.checked = SHAPES[id].visible;
      checkbox.addEventListener('change', (e) => {
        const isChecked = e.target.checked;
        SHAPES[id].visible = isChecked;

        if (isChecked) {
          // When a checkbox is ticked, shape appears at center (0,0)
          SHAPES[id].x = 0;
          SHAPES[id].y = 0;
          bringShapeToFront(id);
          setActiveShape(id);
        } else {
          // If the unchecked shape was active, pick another visible shape
          if (activeShapeId === id) {
            const nextVisible = renderOrder.slice().reverse().find(sid => {
              if (currentViewMode === '2d' && SHAPES[sid].is3DOnly) return false;
              return SHAPES[sid].visible;
            });
            setActiveShape(nextVisible || null);
          }
        }
        updateShapeCountBadge();
        renderAllPanels();
        render();
      });
    }

    if (itemLabel) {
      itemLabel.addEventListener('click', (e) => {
        // If clicking label outside the checkbox, select it as active
        if (e.target !== checkbox) {
          if (SHAPES[id].visible) {
            setActiveShape(id);
            renderAllPanels();
            render();
          }
        }
      });
    }
  });

  updateShapeCountBadge();
}

function updateShapeCountBadge() {
  const badge = document.getElementById('shapeCountBadge');
  if (!badge) return;
  const count = Object.values(SHAPES).filter(s => {
    if (currentViewMode === '2d' && s.is3DOnly) return false;
    return s.visible;
  }).length;
  badge.textContent = `${count} on grid`;
}

function bringShapeToFront(shapeId) {
  const index = renderOrder.indexOf(shapeId);
  if (index !== -1) {
    renderOrder.splice(index, 1);
    renderOrder.push(shapeId);
  }
}

function setActiveShape(shapeId) {
  activeShapeId = shapeId;

  // Highlight active shape in selector
  Object.keys(SHAPES).forEach(id => {
    const item = document.getElementById(`shapeItem_${id}`);
    if (item) {
      if (id === activeShapeId) {
        item.classList.add('active-selected');
      } else {
        item.classList.remove('active-selected');
      }
    }
  });

  renderAllPanels();
}

// --- 2D / 3D Mode Toggle Controls ---
function initViewModeToggle() {
  const btn2D = document.getElementById('btnMode2D');
  const btn3D = document.getElementById('btnMode3D');

  if (btn2D) {
    btn2D.addEventListener('click', () => setViewMode('2d'));
  }
  if (btn3D) {
    btn3D.addEventListener('click', () => setViewMode('3d'));
  }
}

function setViewMode(mode) {
  if (currentViewMode === mode) return;
  currentViewMode = mode;

  const btn2D = document.getElementById('btnMode2D');
  const btn3D = document.getElementById('btnMode3D');
  const shapes3dSec = document.getElementById('shapes3dSection');
  const canvasEl = document.getElementById('geometryCanvas');
  const container3d = document.getElementById('threeJsContainer');

  if (mode === '3d') {
    if (btn2D) btn2D.classList.remove('active');
    if (btn3D) btn3D.classList.add('active');
    if (shapes3dSec) shapes3dSec.style.display = 'block';
    if (canvasEl) canvasEl.style.display = 'none';
    if (container3d) container3d.style.display = 'block';

    initThreeScene();
    rebuildThreeShapes();
  } else {
    if (btn2D) btn2D.classList.add('active');
    if (btn3D) btn3D.classList.remove('active');
    if (shapes3dSec) shapes3dSec.style.display = 'none';
    if (canvasEl) canvasEl.style.display = 'block';
    if (container3d) container3d.style.display = 'none';

    // If active shape is a 3D-only shape, switch to a 2D shape
    if (activeShapeId && SHAPES[activeShapeId] && SHAPES[activeShapeId].is3DOnly) {
      const next2D = renderOrder.slice().reverse().find(sid => !SHAPES[sid].is3DOnly && SHAPES[sid].visible);
      setActiveShape(next2D || 'square');
    }

    disposeThreeScene();
    resizeCanvas();
    render();
  }

  updateShapeCountBadge();
  renderAllPanels();
}

function initDepthSlider() {
  // Depth slider was replaced by number input in Dimensions panel
}

// --- Floating Grid Controls (Zoom & Reset) ---
function initGridControls() {
  const btnZoomIn = document.getElementById('geoZoomInBtn');
  const btnZoomOut = document.getElementById('geoZoomOutBtn');
  const btnReset = document.getElementById('geoResetViewBtn');

  if (btnZoomIn) {
    btnZoomIn.addEventListener('click', () => {
      zoomByCenter(1.25);
    });
  }

  if (btnZoomOut) {
    btnZoomOut.addEventListener('click', () => {
      zoomByCenter(0.8);
    });
  }

  if (btnReset) {
    btnReset.addEventListener('click', () => {
      resetGridOrigin();
    });
  }
}

function zoomByCenter(factor) {
  if (currentViewMode === '3d') {
    if (threeCamera && threeControls) {
      const dir = new THREE.Vector3().subVectors(threeCamera.position, threeControls.target);
      dir.multiplyScalar(factor > 1 ? 0.8 : 1.25);
      threeCamera.position.copy(threeControls.target).add(dir);
      threeControls.update();
    }
    return;
  }

  if (!canvas) return;
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  const centerX = width / 2;
  const centerY = height / 2;
  const mathX = toMathX(centerX);
  const mathY = toMathY(centerY);

  const newScale = Math.max(0.0001, Math.min(20000, gridState.scale * factor));
  gridState.originX = centerX - mathX * newScale;
  gridState.originY = centerY + mathY * newScale;
  gridState.scale = newScale;
  render();
}

function resetGridOrigin() {
  if (currentViewMode === '3d') {
    if (threeCamera && threeControls) {
      threeCamera.position.set(14, 12, 18);
      threeControls.target.set(0, 2, 0);
      threeControls.update();
    }
    return;
  }

  if (!canvas) return;
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  gridState.originX = width / 2;
  gridState.originY = height / 2;
  gridState.scale = 40;
  render();
}

// --- Three.js 3D WebGL Scene Engine ---
function initThreeScene() {
  threeContainer = document.getElementById('threeJsContainer');
  if (!threeContainer) return;

  if (threeRenderer) {
    disposeThreeScene();
  }

  // 1. Scene setup with light gray viewport background
  threeScene = new THREE.Scene();
  threeScene.background = new THREE.Color(0xf0f2f5);

  // 2. Camera setup
  const aspect = window.innerWidth / window.innerHeight;
  threeCamera = new THREE.PerspectiveCamera(45, aspect, 0.1, 1000);
  threeCamera.position.set(14, 12, 18);

  // 3. WebGL Renderer
  threeRenderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  threeRenderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  threeRenderer.setSize(window.innerWidth, window.innerHeight);
  threeRenderer.shadowMap.enabled = true;
  threeRenderer.shadowMap.type = THREE.PCFSoftShadowMap;
  threeContainer.appendChild(threeRenderer.domElement);

  // 4. OrbitControls (360-degree rotation, zoom, pan)
  threeControls = new OrbitControls(threeCamera, threeRenderer.domElement);
  threeControls.target.set(0, 2, 0);
  threeControls.enableDamping = true;
  threeControls.dampingFactor = 0.05;
  threeControls.maxPolarAngle = Math.PI; // Full 360 rotation
  threeControls.minDistance = 2;
  threeControls.maxDistance = 120;
  threeControls.update();

  // 5. Lighting: Soft ambient + directional light
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
  threeScene.add(ambientLight);

  const dirLight = new THREE.DirectionalLight(0xffffff, 0.95);
  dirLight.position.set(16, 26, 20);
  dirLight.castShadow = true;
  dirLight.shadow.mapSize.width = 2048;
  dirLight.shadow.mapSize.height = 2048;
  threeScene.add(dirLight);

  const secondaryLight = new THREE.DirectionalLight(0xffffff, 0.25);
  secondaryLight.position.set(-16, -10, -16);
  threeScene.add(secondaryLight);

  // 6. 3D Floor Grid on X-Z plane at Y=0
  threeGridHelper = new THREE.GridHelper(40, 40, 0x94a3b8, 0xd1d5db);
  threeGridHelper.position.y = 0;
  threeScene.add(threeGridHelper);

  // 7. Colored Axis Lines from origin with tips & labels
  threeAxesGroup = new THREE.Group();
  buildThreeAxes(threeAxesGroup);
  threeScene.add(threeAxesGroup);

  // 8. Shape Group container
  threeShapeGroup = new THREE.Group();
  threeScene.add(threeShapeGroup);

  // 9. Raycasting & Interaction Setup (Drag, Rotate, Select)
  threeRaycaster = new THREE.Raycaster();
  threeMouse = new THREE.Vector2();
  threeDragPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  threePlaneIntersection = new THREE.Vector3();

  initThreeInteraction();

  // 10. Start Animation Loop
  threeAnimate();
}

function threeAnimate() {
  threeAnimFrameId = requestAnimationFrame(threeAnimate);
  if (threeControls) threeControls.update();
  if (threeRenderer && threeScene && threeCamera) {
    threeRenderer.render(threeScene, threeCamera);
  }
}

function buildThreeAxes(group) {
  const L = 14;

  // Materials
  const redMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
  const greenMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
  const blueMat = new THREE.MeshBasicMaterial({ color: 0x3b82f6 });

  // X Axis (Red)
  const geomX = new THREE.CylinderGeometry(0.045, 0.045, L, 16);
  geomX.rotateZ(-Math.PI / 2);
  geomX.translate(L / 2, 0, 0);
  const meshX = new THREE.Mesh(geomX, redMat);
  group.add(meshX);

  const coneGeomX = new THREE.ConeGeometry(0.18, 0.8, 16);
  coneGeomX.rotateZ(-Math.PI / 2);
  coneGeomX.translate(L + 0.4, 0, 0);
  const meshConeX = new THREE.Mesh(coneGeomX, redMat);
  group.add(meshConeX);

  const labelSpriteX = createAxisLabelSprite('x', '#ef4444');
  labelSpriteX.position.set(L + 1.2, 0, 0);
  group.add(labelSpriteX);

  // Y Axis (Green - Upwards)
  const geomY = new THREE.CylinderGeometry(0.045, 0.045, L, 16);
  geomY.translate(0, L / 2, 0);
  const meshY = new THREE.Mesh(geomY, greenMat);
  group.add(meshY);

  const coneGeomY = new THREE.ConeGeometry(0.18, 0.8, 16);
  coneGeomY.translate(0, L + 0.4, 0);
  const meshConeY = new THREE.Mesh(coneGeomY, greenMat);
  group.add(meshConeY);

  const labelSpriteY = createAxisLabelSprite('y', '#10b981');
  labelSpriteY.position.set(0, L + 1.2, 0);
  group.add(labelSpriteY);

  // Z Axis (Blue)
  const geomZ = new THREE.CylinderGeometry(0.045, 0.045, L, 16);
  geomZ.rotateX(Math.PI / 2);
  geomZ.translate(0, 0, L / 2);
  const meshZ = new THREE.Mesh(geomZ, blueMat);
  group.add(meshZ);

  const coneGeomZ = new THREE.ConeGeometry(0.18, 0.8, 16);
  coneGeomZ.rotateX(Math.PI / 2);
  coneGeomZ.translate(0, 0, L + 0.4);
  const meshConeZ = new THREE.Mesh(coneGeomZ, blueMat);
  group.add(meshConeZ);

  const labelSpriteZ = createAxisLabelSprite('z', '#3b82f6');
  labelSpriteZ.position.set(0, 0, L + 1.2);
  group.add(labelSpriteZ);

  // Faint dashed line guides for negative axes
  const faintLineMat = new THREE.LineBasicMaterial({ color: 0x94a3b8, transparent: true, opacity: 0.35 });
  const negPointsX = [new THREE.Vector3(0, 0, 0), new THREE.Vector3(-L, 0, 0)];
  const negGeomX = new THREE.BufferGeometry().setFromPoints(negPointsX);
  group.add(new THREE.Line(negGeomX, faintLineMat));

  const negPointsZ = [new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0, -L)];
  const negGeomZ = new THREE.BufferGeometry().setFromPoints(negPointsZ);
  group.add(new THREE.Line(negGeomZ, faintLineMat));
}

function createAxisLabelSprite(label, colorHex) {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = colorHex;
  ctx.font = 'bold italic 72px "Times New Roman", Times, Georgia, serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, 64, 64);

  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false });
  const sprite = new THREE.Sprite(spriteMat);
  sprite.scale.set(1.5, 1.5, 1);
  return sprite;
}

function createShapeLabelSprite(text, isHighlighted) {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 72;
  const ctx = canvas.getContext('2d');

  // Background rounded pill
  ctx.fillStyle = isHighlighted ? 'rgba(37, 99, 235, 0.95)' : 'rgba(15, 23, 42, 0.78)';
  const r = 16;
  const x = 6, y = 6, w = 244, h = 60;
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = isHighlighted ? '#ffffff' : 'rgba(255, 255, 255, 0.25)';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 24px system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, 128, 36);

  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false });
  const sprite = new THREE.Sprite(spriteMat);
  sprite.scale.set(3.4, 0.95, 1);
  return sprite;
}

function initThreeInteraction() {
  if (!threeRenderer) return;

  threeRenderer.domElement.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || !threeCamera || !threeShapeGroup) return;
    const rect = threeRenderer.domElement.getBoundingClientRect();
    threeMouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    threeMouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    threePointerDownPos.x = e.clientX;
    threePointerDownPos.y = e.clientY;

    threeRaycaster.setFromCamera(threeMouse, threeCamera);
    const intersects = threeRaycaster.intersectObjects(threeShapeGroup.children, true);

    if (intersects.length > 0) {
      let isGizmo = false;
      let shapeId = null;

      for (const hit of intersects) {
        let curr = hit.object;
        while (curr && curr !== threeShapeGroup) {
          if (curr.userData && curr.userData.isRotationGizmo) {
            isGizmo = true;
            shapeId = curr.userData.shapeId;
            break;
          }
          if (curr.userData && curr.userData.shapeId) {
            shapeId = curr.userData.shapeId;
            break;
          }
          curr = curr.parent;
        }
        if (shapeId) break;
      }

      if (shapeId && SHAPES[shapeId]) {
        const shape = SHAPES[shapeId];
        setActiveShape(shapeId);
        if (threeControls) threeControls.enabled = false;

        if (isGizmo || e.shiftKey) {
          is3DRotating = true;
          dragged3DShape = shape;
          if (threeRaycaster.ray.intersectPlane(threeDragPlane, threePlaneIntersection)) {
            threeRotateStartAngle = Math.atan2(threePlaneIntersection.x - shape.x, -(threePlaneIntersection.z - (-shape.y)));
            threeInitialShapeRot = shape.rotation || 0;
          }
        } else {
          is3DDragging = true;
          dragged3DShape = shape;
          if (threeRaycaster.ray.intersectPlane(threeDragPlane, threePlaneIntersection)) {
            threeDragOffset.x = threePlaneIntersection.x - shape.x;
            threeDragOffset.z = threePlaneIntersection.z - (-shape.y);
          }
        }

        rebuildThreeShapes();
        renderAllPanels();
        return;
      }
    }

    // Clicked background: camera OrbitControls handles it
    if (threeControls) threeControls.enabled = true;
  });

  window.addEventListener('pointermove', (e) => {
    if (currentViewMode !== '3d' || !threeRenderer || !threeCamera || !threeShapeGroup) return;

    const rect = threeRenderer.domElement.getBoundingClientRect();
    threeMouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    threeMouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    if (is3DDragging && dragged3DShape) {
      threeRaycaster.setFromCamera(threeMouse, threeCamera);
      if (threeRaycaster.ray.intersectPlane(threeDragPlane, threePlaneIntersection)) {
        dragged3DShape.x = threePlaneIntersection.x - threeDragOffset.x;
        dragged3DShape.y = -(threePlaneIntersection.z - threeDragOffset.z);
        const mesh = threeShapeGroup.children.find(m => m.userData && m.userData.shapeId === dragged3DShape.id);
        if (mesh) {
          mesh.position.x = dragged3DShape.x;
          mesh.position.z = -dragged3DShape.y;
        }
        updateDimensionsPanelValues();
      }
    } else if (is3DRotating && dragged3DShape) {
      threeRaycaster.setFromCamera(threeMouse, threeCamera);
      if (threeRaycaster.ray.intersectPlane(threeDragPlane, threePlaneIntersection)) {
        const currentAngle = Math.atan2(threePlaneIntersection.x - dragged3DShape.x, -(threePlaneIntersection.z - (-dragged3DShape.y)));
        const deltaAngle = currentAngle - threeRotateStartAngle;
        dragged3DShape.rotation = threeInitialShapeRot + deltaAngle;
        const mesh = threeShapeGroup.children.find(m => m.userData && m.userData.shapeId === dragged3DShape.id);
        if (mesh) {
          mesh.rotation.y = dragged3DShape.rotation;
        }
        renderPropertiesPanel();
      }
    } else if (e.target === threeRenderer.domElement) {
      threeRaycaster.setFromCamera(threeMouse, threeCamera);
      const intersects = threeRaycaster.intersectObjects(threeShapeGroup.children, true);
      if (intersects.length > 0) {
        let isGizmo = false;
        let curr = intersects[0].object;
        while (curr && curr !== threeShapeGroup) {
          if (curr.userData && curr.userData.isRotationGizmo) {
            isGizmo = true;
            break;
          }
          curr = curr.parent;
        }
        threeRenderer.domElement.style.cursor = isGizmo || e.shiftKey ? 'crosshair' : 'move';
      } else {
        threeRenderer.domElement.style.cursor = 'default';
      }
    }
  });

  window.addEventListener('pointerup', () => {
    if (currentViewMode !== '3d') return;
    if (is3DDragging || is3DRotating) {
      is3DDragging = false;
      is3DRotating = false;
      dragged3DShape = null;
      if (threeControls) threeControls.enabled = true;
      rebuildThreeShapes();
      renderAllPanels();
    }
  });
}

function rebuildThreeShapes() {
  if (!threeShapeGroup || currentViewMode !== '3d') return;

  // Clear existing meshes & labels
  while (threeShapeGroup.children.length > 0) {
    const child = threeShapeGroup.children[0];
    threeShapeGroup.remove(child);
    disposeThreeObject(child);
  }

  Object.values(SHAPES).forEach(shape => {
    if (!shape.visible) return;

    const isActive = shape.id === activeShapeId;
    let geom = null;
    const shapeDepth = Math.max(0.001, shape.depth !== undefined ? shape.depth : extrusionDepth);
    let labelY = shapeDepth + 0.9;
    let displayName = shape.name;

    switch (shape.id) {
      case 'square': {
        const s = shape.side;
        geom = new THREE.BoxGeometry(s, shapeDepth, s);
        geom.translate(0, shapeDepth / 2, 0);
        displayName = Math.abs(shapeDepth - s) < 1e-4 ? 'Cube' : 'Square Prism';
        break;
      }
      case 'rectangle': {
        const w = shape.width;
        const l = shape.length;
        geom = new THREE.BoxGeometry(w, shapeDepth, l);
        geom.translate(0, shapeDepth / 2, 0);
        displayName = 'Rect Prism';
        break;
      }
      case 'circle': {
        const r = shape.radius;
        geom = new THREE.CylinderGeometry(r, r, shapeDepth, 48);
        geom.translate(0, shapeDepth / 2, 0);
        displayName = 'Cylinder';
        break;
      }
      case 'triangle': {
        const verts = getTriangleVertices({ ...shape, x: 0, y: 0 });
        const triShape = new THREE.Shape();
        triShape.moveTo(verts[0].x, verts[0].y);
        triShape.lineTo(verts[1].x, verts[1].y);
        triShape.lineTo(verts[2].x, verts[2].y);
        triShape.closePath();
        geom = new THREE.ExtrudeGeometry(triShape, { depth: shapeDepth, bevelEnabled: false });
        geom.rotateX(-Math.PI / 2);
        displayName = 'Tri Prism';
        break;
      }
      case 'pentagon': {
        const verts = getRegularPolygonVertices(0, 0, 5, shape.side);
        const polyShape = new THREE.Shape();
        polyShape.moveTo(verts[0].x, verts[0].y);
        for (let i = 1; i < verts.length; i++) polyShape.lineTo(verts[i].x, verts[i].y);
        polyShape.closePath();
        geom = new THREE.ExtrudeGeometry(polyShape, { depth: shapeDepth, bevelEnabled: false });
        geom.rotateX(-Math.PI / 2);
        displayName = 'Pent Prism';
        break;
      }
      case 'hexagon': {
        const verts = getRegularPolygonVertices(0, 0, 6, shape.side);
        const polyShape = new THREE.Shape();
        polyShape.moveTo(verts[0].x, verts[0].y);
        for (let i = 1; i < verts.length; i++) polyShape.lineTo(verts[i].x, verts[i].y);
        polyShape.closePath();
        geom = new THREE.ExtrudeGeometry(polyShape, { depth: shapeDepth, bevelEnabled: false });
        geom.rotateX(-Math.PI / 2);
        displayName = 'Hex Prism';
        break;
      }
      case 'ellipse': {
        const rx = Math.max(0.1, shape.radiusX);
        const ry = Math.max(0.1, shape.radiusY);
        const ellipseShape = new THREE.Shape();
        ellipseShape.absellipse(0, 0, rx, ry, 0, Math.PI * 2, false, 0);
        geom = new THREE.ExtrudeGeometry(ellipseShape, { depth: shapeDepth, bevelEnabled: false, curveSegments: 36 });
        geom.rotateX(-Math.PI / 2);
        displayName = 'Elliptical Cyl';
        break;
      }
      case 'sphere': {
        const r = Math.max(0.1, shape.radius);
        geom = new THREE.SphereGeometry(r, 36, 24);
        geom.translate(0, r, 0);
        labelY = r * 2 + 0.9;
        displayName = 'Sphere';
        break;
      }
      case 'pyramid': {
        const b = Math.max(0.1, shape.baseSize);
        const h = Math.max(0.1, shape.height);
        geom = new THREE.ConeGeometry(b / Math.SQRT2, h, 4);
        geom.rotateY(Math.PI / 4);
        geom.translate(0, h / 2, 0);
        labelY = h + 0.9;
        displayName = 'Pyramid';
        break;
      }
      case 'cone': {
        const r = Math.max(0.1, shape.radius);
        const h = Math.max(0.1, shape.height);
        geom = new THREE.ConeGeometry(r, h, 48);
        geom.translate(0, h / 2, 0);
        labelY = h + 0.9;
        displayName = 'Cone';
        break;
      }
      case 'torus': {
        const R = Math.max(0.5, shape.radius);
        const r = Math.max(0.1, shape.tube);
        geom = new THREE.TorusGeometry(R, r, 24, 48);
        geom.rotateX(Math.PI / 2);
        geom.translate(0, r, 0);
        labelY = r * 2 + 0.9;
        displayName = 'Torus';
        break;
      }
    }

    if (!geom) return;

    // Semi-transparent base material with active emissive glow
    const mat = new THREE.MeshStandardMaterial({
      color: shape.color,
      transparent: true,
      opacity: isActive ? 0.88 : 0.65,
      roughness: 0.25,
      metalness: 0.12,
      side: THREE.DoubleSide
    });

    if (isActive) {
      mat.emissive = new THREE.Color(0x2563eb);
      mat.emissiveIntensity = 0.28;
    }

    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.set(shape.x, 0, -shape.y);
    mesh.rotation.y = shape.rotation || 0;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.userData = { shapeId: shape.id };

    // Edges geometry highlight line
    const edgesGeom = new THREE.EdgesGeometry(geom, 22);
    const edgeMat = new THREE.LineBasicMaterial({
      color: isActive ? 0x2563eb : (shape.strokeColor || shape.color),
      linewidth: isActive ? 3 : 1.5,
      transparent: true,
      opacity: isActive ? 1.0 : 0.8
    });
    const edgeLine = new THREE.LineSegments(edgesGeom, edgeMat);
    mesh.add(edgeLine);

    // Floating shape name label
    const labelSprite = createShapeLabelSprite(displayName, isActive);
    labelSprite.position.set(0, labelY, 0);
    mesh.add(labelSprite);

    // If active, add 3D rotation gizmo around the shape
    if (isActive) {
      const shapeR = Math.max(1.8, getShapeBoundingRadius(shape) + 0.6);
      const gizmoGeom = new THREE.TorusGeometry(shapeR, 0.07, 16, 64);
      gizmoGeom.rotateX(Math.PI / 2);
      gizmoGeom.translate(0, 0.05, 0);

      const gizmoMat = new THREE.MeshBasicMaterial({
        color: 0x2563eb,
        transparent: true,
        opacity: 0.92
      });
      const gizmoMesh = new THREE.Mesh(gizmoGeom, gizmoMat);
      gizmoMesh.userData = { isRotationGizmo: true, shapeId: shape.id };

      const handleGeom = new THREE.SphereGeometry(0.2, 16, 16);
      const handleMat = new THREE.MeshBasicMaterial({ color: 0x60a5fa });
      [0, Math.PI / 2, Math.PI, (3 * Math.PI) / 2].forEach(a => {
        const h = new THREE.Mesh(handleGeom, handleMat);
        h.position.set(shapeR * Math.cos(a), 0.05, shapeR * Math.sin(a));
        h.userData = { isRotationGizmo: true, shapeId: shape.id };
        gizmoMesh.add(h);
      });
      mesh.add(gizmoMesh);
    }

    threeShapeGroup.add(mesh);
  });
}

function disposeThreeObject(obj) {
  if (!obj) return;
  if (obj.geometry) obj.geometry.dispose();
  if (obj.material) {
    if (Array.isArray(obj.material)) {
      obj.material.forEach(m => {
        if (m.map) m.map.dispose();
        m.dispose();
      });
    } else {
      if (obj.material.map) obj.material.map.dispose();
      obj.material.dispose();
    }
  }
  if (obj.children) {
    obj.children.forEach(child => disposeThreeObject(child));
  }
}

function disposeThreeScene() {
  if (threeAnimFrameId) {
    cancelAnimationFrame(threeAnimFrameId);
    threeAnimFrameId = null;
  }
  if (threeControls) {
    threeControls.dispose();
    threeControls = null;
  }
  if (threeShapeGroup) {
    disposeThreeObject(threeShapeGroup);
    threeShapeGroup = null;
  }
  if (threeAxesGroup) {
    disposeThreeObject(threeAxesGroup);
    threeAxesGroup = null;
  }
  if (threeGridHelper) {
    disposeThreeObject(threeGridHelper);
    threeGridHelper = null;
  }
  if (threeRenderer) {
    threeRenderer.dispose();
    if (threeRenderer.domElement && threeRenderer.domElement.parentNode) {
      threeRenderer.domElement.parentNode.removeChild(threeRenderer.domElement);
    }
    threeRenderer = null;
  }
  threeScene = null;
  threeCamera = null;
}

// --- Hit Testing Shapes on Grid ---
function getShapeAtMathCoords(mx, my) {
  // Iterate in reverse render order (top-most first)
  for (let i = renderOrder.length - 1; i >= 0; i--) {
    const shapeId = renderOrder[i];
    const shape = SHAPES[shapeId];
    if (!shape || !shape.visible) continue;

    if (isPointInsideShape(shape, mx, my)) {
      return shape;
    }
  }
  return null;
}

function isPointInsideShape(shape, mx, my) {
  let dx = mx - shape.x;
  let dy = my - shape.y;

  // Account for shape rotation around center
  if (shape.rotation) {
    const cos = Math.cos(-shape.rotation);
    const sin = Math.sin(-shape.rotation);
    const rx = dx * cos - dy * sin;
    const ry = dx * sin + dy * cos;
    dx = rx;
    dy = ry;
  }
  const localMx = shape.x + dx;
  const localMy = shape.y + dy;

  switch (shape.id) {
    case 'square': {
      const half = shape.side / 2;
      return Math.abs(dx) <= half && Math.abs(dy) <= half;
    }
    case 'rectangle': {
      const halfW = shape.width / 2;
      const halfL = shape.length / 2;
      return Math.abs(dx) <= halfW && Math.abs(dy) <= halfL;
    }
    case 'circle': {
      return Math.hypot(dx, dy) <= shape.radius;
    }
    case 'ellipse': {
      const rx = Math.max(0.01, shape.radiusX);
      const ry = Math.max(0.01, shape.radiusY);
      return (dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) <= 1;
    }
    case 'triangle': {
      const verts = getTriangleVertices(shape);
      return isPointInPolygon(localMx, localMy, verts);
    }
    case 'pentagon': {
      const verts = getRegularPolygonVertices(shape.x, shape.y, 5, shape.side);
      return isPointInPolygon(localMx, localMy, verts);
    }
    case 'hexagon': {
      const verts = getRegularPolygonVertices(shape.x, shape.y, 6, shape.side);
      return isPointInPolygon(localMx, localMy, verts);
    }
    default:
      return false;
  }
}

// Triangle Vertices Calculation (Law of Cosines, Centered at (shape.x, shape.y))
function getTriangleVertices(shape) {
  const a = shape.sideA;
  const b = shape.sideB;
  const c = shape.sideC;

  // Validate triangle inequality
  if (a + b <= c || a + c <= b || b + c <= a) {
    // Fallback equilateral for visual stability if invalid
    return getRegularPolygonVertices(shape.x, shape.y, 3, Math.max(1, a));
  }

  // Base is side c along horizontal axis
  // Vertex 1: (0, 0)
  // Vertex 2: (c, 0)
  // Vertex 3: (xC, yC) where xC = (c² + b² - a²) / (2c)
  const xC = (c * c + b * b - a * a) / (2 * c);
  const yC = Math.sqrt(Math.max(0, b * b - xC * xC));

  // Centroid of the triangle
  const centroidX = (0 + c + xC) / 3;
  const centroidY = (0 + 0 + yC) / 3;

  // Center around (shape.x, shape.y)
  return [
    { x: shape.x + (0 - centroidX), y: shape.y + (0 - centroidY) },
    { x: shape.x + (c - centroidX), y: shape.y + (0 - centroidY) },
    { x: shape.x + (xC - centroidX), y: shape.y + (yC - centroidY) }
  ];
}

// Regular Polygon Vertices (Pentagon, Hexagon)
function getRegularPolygonVertices(cx, cy, n, side) {
  const R = side / (2 * Math.sin(Math.PI / n));
  const vertices = [];
  // Rotate slightly so flat side or point is upright
  const startAngle = -Math.PI / 2;
  for (let i = 0; i < n; i++) {
    const angle = startAngle + (i * 2 * Math.PI) / n;
    vertices.push({
      x: cx + R * Math.cos(angle),
      y: cy + R * Math.sin(angle)
    });
  }
  return vertices;
}

// Point-in-polygon ray-casting algorithm
function isPointInPolygon(px, py, vertices) {
  let inside = false;
  for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
    const xi = vertices[i].x;
    const yi = vertices[i].y;
    const xj = vertices[j].x;
    const yj = vertices[j].y;

    const intersect = ((yi > py) !== (yj > py)) &&
      (px < (xj - xi) * (py - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

// --- HTML5 Canvas Infinite Grid & Shape Rendering ---
function render() {
  if (currentViewMode === '3d') {
    rebuildThreeShapes();
    return;
  }

  if (!ctx || !canvas) return;
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;

  // Clear canvas
  ctx.clearRect(0, 0, width, height);

  // 1. Draw Infinite Grid & Axes (Desmos style)
  drawInfiniteGrid(width, height);

  // 2. Draw Shapes in Render Order (skip 3D-only shapes on 2D canvas)
  for (let i = 0; i < renderOrder.length; i++) {
    const shapeId = renderOrder[i];
    const shape = SHAPES[shapeId];
    if (shape && shape.visible && !shape.is3DOnly) {
      const isActive = shape.id === activeShapeId;
      drawShape(shape, isActive);
    }
  }
}

// Draw Desmos-style Grid Lines, Axis Lines & Tick Labels
function drawInfiniteGrid(width, height) {
  const xMin = toMathX(0);
  const xMax = toMathX(width);
  const yMin = toMathY(height);
  const yMax = toMathY(0);

  // Determine nice grid unit step (1, 2, 5 * 10^k)
  const targetPixels = 80;
  const roughStep = targetPixels / gridState.scale;
  const magnitude = Math.pow(10, Math.floor(Math.log10(roughStep)));
  const ratio = roughStep / magnitude;

  let majorStep = magnitude;
  if (ratio < 1.5) majorStep = 1 * magnitude;
  else if (ratio < 3.5) majorStep = 2 * magnitude;
  else if (ratio < 7.5) majorStep = 5 * magnitude;
  else majorStep = 10 * magnitude;

  // Subdivisions: 5 minor divisions per major step
  const minorStep = majorStep / 5;

  ctx.save();

  // --- Minor Grid Lines ---
  ctx.lineWidth = 1;
  ctx.strokeStyle = 'rgba(15, 23, 42, 0.06)';

  ctx.beginPath();
  const startMinorX = Math.floor(xMin / minorStep) * minorStep;
  for (let x = startMinorX; x <= xMax; x += minorStep) {
    const sx = Math.round(toScreenX(x)) + 0.5;
    ctx.moveTo(sx, 0);
    ctx.lineTo(sx, height);
  }

  const startMinorY = Math.floor(yMin / minorStep) * minorStep;
  for (let y = startMinorY; y <= yMax; y += minorStep) {
    const sy = Math.round(toScreenY(y)) + 0.5;
    ctx.moveTo(0, sy);
    ctx.lineTo(width, sy);
  }
  ctx.stroke();

  // --- Major Grid Lines (Darker lines every 5 units / major steps) ---
  ctx.lineWidth = 1.2;
  ctx.strokeStyle = 'rgba(15, 23, 42, 0.14)';

  ctx.beginPath();
  const startMajorX = Math.floor(xMin / majorStep) * majorStep;
  for (let x = startMajorX; x <= xMax; x += majorStep) {
    const sx = Math.round(toScreenX(x)) + 0.5;
    ctx.moveTo(sx, 0);
    ctx.lineTo(sx, height);
  }

  const startMajorY = Math.floor(yMin / majorStep) * majorStep;
  for (let y = startMajorY; y <= yMax; y += majorStep) {
    const sy = Math.round(toScreenY(y)) + 0.5;
    ctx.moveTo(0, sy);
    ctx.lineTo(width, sy);
  }
  ctx.stroke();

  // --- Main Axis Lines (X and Y) ---
  const screenOriginX = Math.round(gridState.originX) + 0.5;
  const screenOriginY = Math.round(gridState.originY) + 0.5;

  ctx.lineWidth = 2;
  ctx.strokeStyle = '#334155';

  ctx.beginPath();
  // X axis (horizontal line y=0)
  ctx.moveTo(0, screenOriginY);
  ctx.lineTo(width, screenOriginY);
  // Y axis (vertical line x=0)
  ctx.moveTo(screenOriginX, 0);
  ctx.lineTo(screenOriginX, height);
  ctx.stroke();

  // --- Axis Tick Labels (Desmos-like dynamic numbers) ---
  ctx.font = '500 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  ctx.fillStyle = '#64748b';

  // Determine label position pinning if axes are off screen
  const axisLabelPosY = Math.max(22, Math.min(height - 10, screenOriginY + 16));
  const axisLabelPosX = Math.max(34, Math.min(width - 12, screenOriginX - 8));

  // X Axis Labels
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';

  for (let x = startMajorX; x <= xMax; x += majorStep) {
    // Avoid drawing directly on origin intersection
    if (Math.abs(x) < majorStep * 0.05) continue;
    const sx = toScreenX(x);
    if (sx < 25 || sx > width - 25) continue;

    // Small tick notch on axis
    if (screenOriginY >= 0 && screenOriginY <= height) {
      ctx.beginPath();
      ctx.moveTo(sx, screenOriginY - 4);
      ctx.lineTo(sx, screenOriginY + 4);
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    ctx.fillText(formatGridNumber(x), sx, axisLabelPosY);
  }

  // Y Axis Labels
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';

  for (let y = startMajorY; y <= yMax; y += majorStep) {
    if (Math.abs(y) < majorStep * 0.05) continue;
    const sy = toScreenY(y);
    if (sy < 20 || sy > height - 20) continue;

    // Small tick notch on axis
    if (screenOriginX >= 0 && screenOriginX <= width) {
      ctx.beginPath();
      ctx.moveTo(screenOriginX - 4, sy);
      ctx.lineTo(screenOriginX + 4, sy);
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    ctx.fillText(formatGridNumber(y), axisLabelPosX, sy);
  }

  // Origin "0" label
  if (screenOriginX >= 15 && screenOriginX <= width - 15 &&
      screenOriginY >= 15 && screenOriginY <= height - 15) {
    ctx.textAlign = 'right';
    ctx.textBaseline = 'top';
    ctx.fillText('0', screenOriginX - 6, screenOriginY + 5);
  }

  ctx.restore();
}

// Clean number formatting for tick marks (avoids floating point artifacts)
function formatGridNumber(val) {
  if (Math.abs(val) >= 10000 || (Math.abs(val) > 0 && Math.abs(val) < 0.001)) {
    return val.toExponential(1);
  }
  // Round to up to 4 significant digits without trailing zeros
  const rounded = Number(val.toPrecision(6));
  return String(rounded);
}

// Draw an individual Shape onto Canvas
function drawShape(shape, isActive) {
  ctx.save();

  const sx = toScreenX(shape.x);
  const sy = toScreenY(shape.y);

  // Apply rotation transformation around shape's center
  if (shape.rotation) {
    ctx.translate(sx, sy);
    ctx.rotate(shape.rotation);
    ctx.translate(-sx, -sy);
  }

  // Active shape selection glow/outline
  if (isActive) {
    ctx.shadowColor = 'rgba(37, 99, 235, 0.55)';
    ctx.shadowBlur = 14;
  }

  ctx.fillStyle = shape.fillColor;
  ctx.strokeStyle = isActive ? '#2563eb' : shape.strokeColor;
  ctx.lineWidth = isActive ? 2.5 : 2;

  let labelText = '';

  switch (shape.id) {
    case 'square': {
      const s = shape.side * gridState.scale;
      ctx.beginPath();
      ctx.rect(sx - s / 2, sy - s / 2, s, s);
      ctx.fill();
      ctx.stroke();
      labelText = `${shape.side} × ${shape.side}`;
      break;
    }
    case 'rectangle': {
      const w = shape.width * gridState.scale;
      const l = shape.length * gridState.scale;
      ctx.beginPath();
      ctx.rect(sx - w / 2, sy - l / 2, w, l);
      ctx.fill();
      ctx.stroke();
      labelText = `${shape.width} × ${shape.length}`;
      break;
    }
    case 'circle': {
      const r = shape.radius * gridState.scale;
      ctx.beginPath();
      ctx.arc(sx, sy, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Radius reference line from center to right
      ctx.beginPath();
      ctx.setLineDash([3, 3]);
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx + r, sy);
      ctx.strokeStyle = shape.strokeColor;
      ctx.stroke();
      ctx.setLineDash([]);

      labelText = `r = ${shape.radius}`;
      break;
    }
    case 'ellipse': {
      const rx = shape.radiusX * gridState.scale;
      const ry = shape.radiusY * gridState.scale;
      ctx.beginPath();
      ctx.ellipse(sx, sy, Math.max(1, rx), Math.max(1, ry), 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      labelText = `${shape.radiusX} × ${shape.radiusY}`;
      break;
    }
    case 'triangle': {
      const verts = getTriangleVertices(shape);
      ctx.beginPath();
      for (let i = 0; i < verts.length; i++) {
        const vx = toScreenX(verts[i].x);
        const vy = toScreenY(verts[i].y);
        if (i === 0) ctx.moveTo(vx, vy);
        else ctx.lineTo(vx, vy);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      labelText = `${shape.sideA}, ${shape.sideB}, ${shape.sideC}`;
      break;
    }
    case 'pentagon': {
      const verts = getRegularPolygonVertices(shape.x, shape.y, 5, shape.side);
      ctx.beginPath();
      for (let i = 0; i < verts.length; i++) {
        const vx = toScreenX(verts[i].x);
        const vy = toScreenY(verts[i].y);
        if (i === 0) ctx.moveTo(vx, vy);
        else ctx.lineTo(vx, vy);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      labelText = `Side: ${shape.side}`;
      break;
    }
    case 'hexagon': {
      const verts = getRegularPolygonVertices(shape.x, shape.y, 6, shape.side);
      ctx.beginPath();
      for (let i = 0; i < verts.length; i++) {
        const vx = toScreenX(verts[i].x);
        const vy = toScreenY(verts[i].y);
        if (i === 0) ctx.moveTo(vx, vy);
        else ctx.lineTo(vx, vy);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      labelText = `Side: ${shape.side}`;
      break;
    }
  }

  // Draw Center Point Indicator
  ctx.shadowBlur = 0;
  ctx.beginPath();
  ctx.arc(sx, sy, 3.5, 0, Math.PI * 2);
  ctx.fillStyle = isActive ? '#2563eb' : shape.color;
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Draw Dimension Badge on Shape (matching ASCII summary: [2×4])
  if (labelText) {
    drawDimensionBadge(sx, sy - 8, labelText, shape.color);
  }

  // If active, draw clean selection indicator corners & rotation handle
  if (isActive) {
    drawActiveSelectionIndicators(shape, sx, sy);
  }

  ctx.restore();
}

// Draw centered dimension text tag on shape
function drawDimensionBadge(x, y, text, themeColor) {
  ctx.save();
  ctx.font = '600 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  const textWidth = ctx.measureText(text).width;
  const paddingX = 7;
  const paddingY = 3.5;
  const badgeWidth = textWidth + paddingX * 2;
  const badgeHeight = 18;

  // Background pill
  ctx.fillStyle = 'rgba(255, 255, 255, 0.94)';
  ctx.strokeStyle = 'rgba(203, 213, 225, 0.9)';
  ctx.lineWidth = 1;
  ctx.shadowColor = 'rgba(0, 0, 0, 0.08)';
  ctx.shadowBlur = 4;
  ctx.shadowOffsetY = 1;

  ctx.beginPath();
  ctx.roundRect(x - badgeWidth / 2, y - badgeHeight / 2, badgeWidth, badgeHeight, 6);
  ctx.fill();
  ctx.stroke();

  // Text
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;
  ctx.fillStyle = '#1e293b';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, x, y);
  ctx.restore();
}

// Subtle dashed selection boundary and rotation handle for active shape
function drawActiveSelectionIndicators(shape, sx, sy) {
  ctx.save();
  ctx.strokeStyle = '#2563eb';
  ctx.lineWidth = 1.5;
  ctx.setLineDash([4, 4]);

  const { halfW, halfH } = getShapeHalfExtents(shape);

  // 1. Dashed bounding box
  ctx.beginPath();
  ctx.roundRect(sx - halfW, sy - halfH, halfW * 2, halfH * 2, 8);
  ctx.stroke();

  // 2. Rotation handle stem & handle knob
  const stem = 24;
  ctx.beginPath();
  ctx.setLineDash([]);
  ctx.moveTo(sx, sy - halfH);
  ctx.lineTo(sx, sy - halfH - stem);
  ctx.strokeStyle = '#2563eb';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Handle circle
  ctx.beginPath();
  ctx.arc(sx, sy - halfH - stem, 6, 0, Math.PI * 2);
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  ctx.strokeStyle = '#2563eb';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Handle center dot
  ctx.beginPath();
  ctx.arc(sx, sy - halfH - stem, 2, 0, Math.PI * 2);
  ctx.fillStyle = '#2563eb';
  ctx.fill();

  ctx.restore();
}

// --- DIMENSIONS PANEL (Bottom-Left) ---
function renderAllPanels() {
  renderDimensionsPanel();
  renderPropertiesPanel();
}

function renderDimensionsPanel() {
  const badge = document.getElementById('dimActiveShapeTag');
  const body = document.getElementById('dimensionsBody');
  if (!body) return;

  const shape = activeShapeId ? SHAPES[activeShapeId] : null;

  if (!shape || !shape.visible) {
    if (badge) badge.textContent = 'None';
    body.innerHTML = `
      <div class="no-active-shape-msg">
        Select a shape from the Shapes panel to view &amp; edit dimensions.
      </div>
    `;
    return;
  }

  if (badge) badge.textContent = shape.name;

  let inputsHtml = '';

  switch (shape.id) {
    case 'square':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_square_side">Side:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_square_side" class="dim-number-input"
                   min="0.001" step="any" value="${shape.side}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;

    case 'rectangle':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_rect_width">Width:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_rect_width" class="dim-number-input"
                   min="0.001" step="any" value="${shape.width}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
        <div class="dim-input-row">
          <label class="dim-label" for="dim_rect_length">Length:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_rect_length" class="dim-number-input"
                   min="0.001" step="any" value="${shape.length}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;

    case 'circle':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_circle_radius">Radius:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_circle_radius" class="dim-number-input"
                   min="0.001" step="any" value="${shape.radius}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;

    case 'triangle':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_tri_a">Side A:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_tri_a" class="dim-number-input"
                   min="0.001" step="any" value="${shape.sideA}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
        <div class="dim-input-row">
          <label class="dim-label" for="dim_tri_b">Side B:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_tri_b" class="dim-number-input"
                   min="0.001" step="any" value="${shape.sideB}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
        <div class="dim-input-row">
          <label class="dim-label" for="dim_tri_c">Side C:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_tri_c" class="dim-number-input"
                   min="0.001" step="any" value="${shape.sideC}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;

    case 'pentagon':
    case 'hexagon':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_poly_side">Side:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_poly_side" class="dim-number-input"
                   min="0.001" step="any" value="${shape.side}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;

    case 'ellipse':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_ellipse_rx">Radius X:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_ellipse_rx" class="dim-number-input"
                   min="0.001" step="any" value="${shape.radiusX}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
        <div class="dim-input-row">
          <label class="dim-label" for="dim_ellipse_ry">Radius Y:</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_ellipse_ry" class="dim-number-input"
                   min="0.001" step="any" value="${shape.radiusY}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;

    case 'sphere':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_sphere_radius">Radius (r):</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_sphere_radius" class="dim-number-input"
                   min="0.001" step="any" value="${shape.radius}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;

    case 'pyramid':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_pyramid_base">Base Side (b):</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_pyramid_base" class="dim-number-input"
                   min="0.001" step="any" value="${shape.baseSize}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
        <div class="dim-input-row">
          <label class="dim-label" for="dim_pyramid_height">Height (h):</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_pyramid_height" class="dim-number-input"
                   min="0.001" step="any" value="${shape.height}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;

    case 'cone':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_cone_radius">Radius (r):</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_cone_radius" class="dim-number-input"
                   min="0.001" step="any" value="${shape.radius}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
        <div class="dim-input-row">
          <label class="dim-label" for="dim_cone_height">Height (h):</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_cone_height" class="dim-number-input"
                   min="0.001" step="any" value="${shape.height}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;

    case 'torus':
      inputsHtml = `
        <div class="dim-input-row">
          <label class="dim-label" for="dim_torus_radius">Radius (R):</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_torus_radius" class="dim-number-input"
                   min="0.001" step="any" value="${shape.radius}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
        <div class="dim-input-row">
          <label class="dim-label" for="dim_torus_tube">Tube (r):</label>
          <div class="dim-control-wrap">
            <input type="number" id="dim_torus_tube" class="dim-number-input"
                   min="0.001" step="any" value="${shape.tube}" />
            <span class="dim-unit">units</span>
          </div>
        </div>
      `;
      break;
  }

  // If in 3D mode and shape is an extruded 2D shape, add Height / Depth input box (no max limit)
  const isExtruded = ['square', 'rectangle', 'circle', 'triangle', 'pentagon', 'hexagon', 'ellipse'].includes(shape.id);
  let depthRowHtml = '';
  if (currentViewMode === '3d' && isExtruded) {
    const currentDepth = shape.depth !== undefined ? shape.depth : extrusionDepth;
    depthRowHtml = `
      <div class="dim-input-row">
        <label class="dim-label" for="dim_shape_depth">Height / Depth:</label>
        <div class="dim-control-wrap">
          <input type="number" id="dim_shape_depth" class="dim-number-input"
                 min="0.001" step="any" value="${currentDepth}" />
          <span class="dim-unit">units</span>
        </div>
      </div>
    `;
  }

  body.innerHTML = `
    ${inputsHtml}
    ${depthRowHtml}
    <div class="dim-footer-note">
      <span id="shapePosLabel">Center: (${shape.x.toFixed(1)}, ${shape.y.toFixed(1)})</span>
      <button type="button" class="dim-center-btn" id="btnCenterShape" title="Center shape at (0,0)">
        Center at (0,0)
      </button>
    </div>
    <div id="triangleWarning" style="display: none;" class="dim-warning-msg">
      Invalid triangle: sum of any two sides must exceed the third.
    </div>
  `;

  // Attach event listeners to input elements
  attachDimensionInputListeners(shape);
}

function attachDimensionInputListeners(shape) {
  const btnCenter = document.getElementById('btnCenterShape');
  if (btnCenter) {
    btnCenter.addEventListener('click', () => {
      shape.x = 0;
      shape.y = 0;
      render();
      if (currentViewMode === '3d') {
        rebuildThreeShapes();
      }
      updateDimensionsPanelValues();
    });
  }

  // Handle Height / Depth input in 3D mode
  const depthInput = document.getElementById('dim_shape_depth');
  if (depthInput) {
    const onDepthChange = () => {
      const parsed = parseFloat(depthInput.value);
      if (!isNaN(parsed) && parsed > 0) {
        shape.depth = parsed;
        extrusionDepth = parsed;
        if (currentViewMode === '3d') {
          rebuildThreeShapes();
          renderPropertiesPanel();
        }
      }
    };
    depthInput.addEventListener('input', onDepthChange);
    depthInput.addEventListener('change', onDepthChange);
  }

  const handleInputUpdate = (inputEl, property) => {
    if (!inputEl) return;
    const updateVal = () => {
      const parsed = parseFloat(inputEl.value);
      if (!isNaN(parsed) && parsed > 0) {
        shape[property] = parsed;

        // If triangle, check inequality
        if (shape.id === 'triangle') {
          const a = shape.sideA;
          const b = shape.sideB;
          const c = shape.sideC;
          const warnEl = document.getElementById('triangleWarning');
          if (warnEl) {
            warnEl.style.display = (a + b <= c || a + c <= b || b + c <= a) ? 'block' : 'none';
          }
        }

        render();
        if (currentViewMode === '3d') {
          rebuildThreeShapes();
        }
        renderPropertiesPanel();
      }
    };

    inputEl.addEventListener('input', updateVal);
    inputEl.addEventListener('change', updateVal);
  };

  switch (shape.id) {
    case 'square':
      handleInputUpdate(document.getElementById('dim_square_side'), 'side');
      break;
    case 'rectangle':
      handleInputUpdate(document.getElementById('dim_rect_width'), 'width');
      handleInputUpdate(document.getElementById('dim_rect_length'), 'length');
      break;
    case 'circle':
      handleInputUpdate(document.getElementById('dim_circle_radius'), 'radius');
      break;
    case 'triangle':
      handleInputUpdate(document.getElementById('dim_tri_a'), 'sideA');
      handleInputUpdate(document.getElementById('dim_tri_b'), 'sideB');
      handleInputUpdate(document.getElementById('dim_tri_c'), 'sideC');
      break;
    case 'pentagon':
    case 'hexagon':
      handleInputUpdate(document.getElementById('dim_poly_side'), 'side');
      break;
    case 'ellipse':
      handleInputUpdate(document.getElementById('dim_ellipse_rx'), 'radiusX');
      handleInputUpdate(document.getElementById('dim_ellipse_ry'), 'radiusY');
      break;
    case 'sphere':
      handleInputUpdate(document.getElementById('dim_sphere_radius'), 'radius');
      break;
    case 'pyramid':
      handleInputUpdate(document.getElementById('dim_pyramid_base'), 'baseSize');
      handleInputUpdate(document.getElementById('dim_pyramid_height'), 'height');
      break;
    case 'cone':
      handleInputUpdate(document.getElementById('dim_cone_radius'), 'radius');
      handleInputUpdate(document.getElementById('dim_cone_height'), 'height');
      break;
    case 'torus':
      handleInputUpdate(document.getElementById('dim_torus_radius'), 'radius');
      handleInputUpdate(document.getElementById('dim_torus_tube'), 'tube');
      break;
  }
}

function updateDimensionsPanelValues() {
  const shape = activeShapeId ? SHAPES[activeShapeId] : null;
  if (!shape) return;
  const posLabel = document.getElementById('shapePosLabel');
  if (posLabel) {
    posLabel.textContent = `Center: (${shape.x.toFixed(1)}, ${shape.y.toFixed(1)})`;
  }
}

// --- PROPERTIES / CALCULATOR PANEL (Bottom-Right) ---
function renderPropertiesPanel() {
  const badge = document.getElementById('propActiveShapeTag');
  const body = document.getElementById('propertiesBody');
  if (!body) return;

  const shape = activeShapeId ? SHAPES[activeShapeId] : null;

  if (!shape || !shape.visible) {
    if (badge) badge.textContent = 'None';
    body.innerHTML = `
      <div class="no-active-shape-msg">
        Select a shape from the Shapes panel to view properties.
      </div>
    `;
    return;
  }

  let rows = [];
  let formulaText = '';
  const is3D = currentViewMode === '3d';

  if (is3D) {
    // 3D Geometry Calculations (Extruded 2D Shapes & 3D Solids)
    const depth = Math.max(0.001, extrusionDepth);

    switch (shape.id) {
      case 'square': {
        const s = shape.side;
        const baseArea = s * s;
        const volume = baseArea * depth;
        const surfaceArea = 2 * baseArea + 4 * s * depth;
        const isCube = Math.abs(s - depth) < 1e-4;

        if (badge) badge.textContent = isCube ? 'Cube' : 'Square Prism';
        rows = [
          { label: 'Side (s):', value: `${formatMetric(s)} units` },
          { label: 'Height / Depth (h):', value: `${formatMetric(depth)} units` },
          { label: 'Base Area:', value: `${formatMetric(baseArea)} sq units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = isCube ? 'Volume = s³  |  Surface Area = 6s²' : 'Volume = s² × h  |  Surface Area = 2s² + 4sh';
        break;
      }

      case 'rectangle': {
        const w = shape.width;
        const l = shape.length;
        const baseArea = w * l;
        const volume = baseArea * depth;
        const surfaceArea = 2 * (w * l + w * depth + l * depth);

        if (badge) badge.textContent = 'Rectangular Prism';
        rows = [
          { label: 'Width (w):', value: `${formatMetric(w)} units` },
          { label: 'Length (l):', value: `${formatMetric(l)} units` },
          { label: 'Height / Depth (h):', value: `${formatMetric(depth)} units` },
          { label: 'Base Area:', value: `${formatMetric(baseArea)} sq units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = w × l × h  |  Surface Area = 2(wl + wh + lh)';
        break;
      }

      case 'circle': {
        const r = shape.radius;
        const baseArea = Math.PI * r * r;
        const lateralArea = 2 * Math.PI * r * depth;
        const volume = baseArea * depth;
        const surfaceArea = 2 * baseArea + lateralArea;

        if (badge) badge.textContent = 'Cylinder';
        rows = [
          { label: 'Radius (r):', value: `${formatMetric(r)} units` },
          { label: 'Height (h):', value: `${formatMetric(depth)} units` },
          { label: 'Base Area:', value: `${formatMetric(baseArea)} sq units` },
          { label: 'Lateral Area:', value: `${formatMetric(lateralArea)} sq units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = πr²h  |  Surface Area = 2πr² + 2πrh';
        break;
      }

      case 'triangle': {
        const a = shape.sideA;
        const b = shape.sideB;
        const c = shape.sideC;
        const perimeter = a + b + c;
        const s = perimeter / 2;
        const radicand = s * (s - a) * (s - b) * (s - c);
        const isValid = (a + b > c) && (a + c > b) && (b + c > a) && radicand > 0;
        const baseArea = isValid ? Math.sqrt(radicand) : 0;
        const volume = baseArea * depth;
        const surfaceArea = 2 * baseArea + perimeter * depth;

        if (badge) badge.textContent = 'Triangular Prism';
        rows = [
          { label: 'Base Sides:', value: `${formatMetric(a)}, ${formatMetric(b)}, ${formatMetric(c)}` },
          { label: 'Height (h):', value: `${formatMetric(depth)} units` },
          { label: 'Base Area:', value: `${formatMetric(baseArea)} sq units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = (Base Area) × h  |  Surface Area = 2(Base Area) + (a+b+c)h';
        break;
      }

      case 'pentagon': {
        const s = shape.side;
        const apothem = s / (2 * Math.tan(Math.PI / 5));
        const baseArea = (5 / 2) * s * apothem;
        const volume = baseArea * depth;
        const surfaceArea = 2 * baseArea + 5 * s * depth;

        if (badge) badge.textContent = 'Pentagonal Prism';
        rows = [
          { label: 'Base Side (s):', value: `${formatMetric(s)} units` },
          { label: 'Height (h):', value: `${formatMetric(depth)} units` },
          { label: 'Base Area:', value: `${formatMetric(baseArea)} sq units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = (Base Area) × h  |  Surface Area = 2(Base Area) + 5sh';
        break;
      }

      case 'hexagon': {
        const s = shape.side;
        const baseArea = ((3 * Math.sqrt(3)) / 2) * s * s;
        const volume = baseArea * depth;
        const surfaceArea = 2 * baseArea + 6 * s * depth;

        if (badge) badge.textContent = 'Hexagonal Prism';
        rows = [
          { label: 'Base Side (s):', value: `${formatMetric(s)} units` },
          { label: 'Height (h):', value: `${formatMetric(depth)} units` },
          { label: 'Base Area:', value: `${formatMetric(baseArea)} sq units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = ((3√3)/2)s² × h  |  Surface Area = 3√3s² + 6sh';
        break;
      }

      case 'ellipse': {
        const a = shape.radiusX;
        const b = shape.radiusY;
        const baseArea = Math.PI * a * b;
        const hParam = Math.pow(a - b, 2) / Math.pow(a + b, 2);
        const perimeter = Math.PI * (a + b) * (1 + (3 * hParam) / (10 + Math.sqrt(4 - 3 * hParam)));
        const volume = baseArea * depth;
        const surfaceArea = 2 * baseArea + perimeter * depth;

        if (badge) badge.textContent = 'Elliptical Cylinder';
        rows = [
          { label: 'Radius X (a):', value: `${formatMetric(a)} units` },
          { label: 'Radius Y (b):', value: `${formatMetric(b)} units` },
          { label: 'Height (h):', value: `${formatMetric(depth)} units` },
          { label: 'Base Area:', value: `${formatMetric(baseArea)} sq units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = πabh  |  Surface Area = 2πab + (Perimeter) × h';
        break;
      }

      case 'sphere': {
        const r = shape.radius;
        const diameter = 2 * r;
        const volume = (4 / 3) * Math.PI * Math.pow(r, 3);
        const surfaceArea = 4 * Math.PI * r * r;

        if (badge) badge.textContent = 'Sphere';
        rows = [
          { label: 'Radius (r):', value: `${formatMetric(r)} units` },
          { label: 'Diameter (d):', value: `${formatMetric(diameter)} units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = ⁴⁄₃πr³  |  Surface Area = 4πr²  |  Diameter = 2r';
        break;
      }

      case 'pyramid': {
        const b = shape.baseSize;
        const h = shape.height;
        const baseArea = b * b;
        const slantHeight = Math.hypot(h, b / 2);
        const volume = (1 / 3) * baseArea * h;
        const surfaceArea = baseArea + 2 * b * slantHeight;

        if (badge) badge.textContent = 'Square Pyramid';
        rows = [
          { label: 'Base Side (b):', value: `${formatMetric(b)} units` },
          { label: 'Height (h):', value: `${formatMetric(h)} units` },
          { label: 'Slant Height (s):', value: `${formatMetric(slantHeight)} units` },
          { label: 'Base Area:', value: `${formatMetric(baseArea)} sq units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = ⅓b²h  |  Surface Area = b² + 2bs  (s = √(h² + (b/2)²))';
        break;
      }

      case 'cone': {
        const r = shape.radius;
        const h = shape.height;
        const slantHeight = Math.hypot(r, h);
        const baseArea = Math.PI * r * r;
        const volume = (1 / 3) * Math.PI * r * r * h;
        const surfaceArea = Math.PI * r * (r + slantHeight);

        if (badge) badge.textContent = 'Cone';
        rows = [
          { label: 'Radius (r):', value: `${formatMetric(r)} units` },
          { label: 'Height (h):', value: `${formatMetric(h)} units` },
          { label: 'Slant Height (s):', value: `${formatMetric(slantHeight)} units` },
          { label: 'Base Area:', value: `${formatMetric(baseArea)} sq units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = ⅓πr²h  |  Surface Area = πr(r + s)  (s = √(r² + h²))';
        break;
      }

      case 'torus': {
        const R = shape.radius;
        const r = shape.tube;
        const volume = 2 * Math.PI * Math.PI * R * r * r;
        const surfaceArea = 4 * Math.PI * Math.PI * R * r;

        if (badge) badge.textContent = 'Torus / Donut';
        rows = [
          { label: 'Major Radius (R):', value: `${formatMetric(R)} units` },
          { label: 'Tube Radius (r):', value: `${formatMetric(r)} units` },
          { label: 'Volume:', value: `${formatMetric(volume)} cu units` },
          { label: 'Surface Area:', value: `${formatMetric(surfaceArea)} sq units` }
        ];
        formulaText = 'Volume = 2π²Rr²  |  Surface Area = 4π²Rr';
        break;
      }
    }
  } else {
    // 2D Geometry Calculations
    if (badge) badge.textContent = shape.name;

    switch (shape.id) {
      case 'square': {
        const s = shape.side;
        const area = s * s;
        const perimeter = 4 * s;
        const diagonal = s * Math.SQRT2;

        rows = [
          { label: 'Side:', value: `${formatMetric(s)} units` },
          { label: 'Area:', value: `${formatMetric(area)} sq units` },
          { label: 'Perimeter:', value: `${formatMetric(perimeter)} units` },
          { label: 'Diagonal:', value: `${formatMetric(diagonal)} units` }
        ];
        formulaText = 'Area = s²  |  Perimeter = 4s  |  Diagonal = s√2';
        break;
      }

      case 'rectangle': {
        const w = shape.width;
        const l = shape.length;
        const area = w * l;
        const perimeter = 2 * (w + l);
        const diagonal = Math.hypot(w, l);

        rows = [
          { label: 'Width:', value: `${formatMetric(w)} units` },
          { label: 'Length:', value: `${formatMetric(l)} units` },
          { label: 'Area:', value: `${formatMetric(area)} sq units` },
          { label: 'Perimeter:', value: `${formatMetric(perimeter)} units` },
          { label: 'Diagonal:', value: `${formatMetric(diagonal)} units` }
        ];
        formulaText = 'Area = w × l  |  Perimeter = 2(w + l)  |  Diagonal = √(w² + l²)';
        break;
      }

      case 'circle': {
        const r = shape.radius;
        const diameter = 2 * r;
        const area = Math.PI * r * r;
        const circumference = 2 * Math.PI * r;

        rows = [
          { label: 'Radius:', value: `${formatMetric(r)} units` },
          { label: 'Diameter:', value: `${formatMetric(diameter)} units` },
          { label: 'Area:', value: `${formatMetric(area)} sq units` },
          { label: 'Circumference:', value: `${formatMetric(circumference)} units` }
        ];
        formulaText = 'Area = πr²  |  Circumference = 2πr  |  Diameter = 2r';
        break;
      }

      case 'triangle': {
        const a = shape.sideA;
        const b = shape.sideB;
        const c = shape.sideC;

        const perimeter = a + b + c;
        const s = perimeter / 2;
        const radicand = s * (s - a) * (s - b) * (s - c);
        const isValid = (a + b > c) && (a + c > b) && (b + c > a) && radicand > 0;
        const area = isValid ? Math.sqrt(radicand) : 0;

        let triType = 'Scalene';
        if (Math.abs(a - b) < 1e-4 && Math.abs(b - c) < 1e-4) {
          triType = 'Equilateral';
        } else if (Math.abs(a - b) < 1e-4 || Math.abs(b - c) < 1e-4 || Math.abs(a - c) < 1e-4) {
          triType = 'Isosceles';
        }

        const sorted = [a, b, c].sort((x, y) => x - y);
        const diff = sorted[0] * sorted[0] + sorted[1] * sorted[1] - sorted[2] * sorted[2];
        if (Math.abs(diff) < 0.05 * sorted[2] * sorted[2]) {
          triType = 'Right Triangle';
        }

        rows = [
          { label: 'Sides:', value: `${formatMetric(a)}, ${formatMetric(b)}, ${formatMetric(c)}` },
          { label: 'Area:', value: `${formatMetric(area)} sq units` },
          { label: 'Perimeter:', value: `${formatMetric(perimeter)} units` },
          { label: 'Type:', value: triType }
        ];
        formulaText = "Heron's Formula: Area = √(s(s-a)(s-b)(s-c)) where s = (a+b+c)/2";
        break;
      }

      case 'pentagon': {
        const s = shape.side;
        const perimeter = 5 * s;
        const apothem = s / (2 * Math.tan(Math.PI / 5));
        const area = (5 / 2) * s * apothem;

        rows = [
          { label: 'Side:', value: `${formatMetric(s)} units` },
          { label: 'Area:', value: `${formatMetric(area)} sq units` },
          { label: 'Perimeter:', value: `${formatMetric(perimeter)} units` },
          { label: 'Apothem:', value: `${formatMetric(apothem)} units` },
          { label: 'Interior Angle:', value: '108°' }
        ];
        formulaText = 'Area = ½ × Perimeter × Apothem  |  Apothem = s / (2 tan(36°))';
        break;
      }

      case 'hexagon': {
        const s = shape.side;
        const perimeter = 6 * s;
        const apothem = (s * Math.sqrt(3)) / 2;
        const area = ((3 * Math.sqrt(3)) / 2) * s * s;
        const longDiagonal = 2 * s;

        rows = [
          { label: 'Side:', value: `${formatMetric(s)} units` },
          { label: 'Area:', value: `${formatMetric(area)} sq units` },
          { label: 'Perimeter:', value: `${formatMetric(perimeter)} units` },
          { label: 'Apothem:', value: `${formatMetric(apothem)} units` },
          { label: 'Interior Angle:', value: '120°' },
          { label: 'Long Diagonal:', value: `${formatMetric(longDiagonal)} units` }
        ];
        formulaText = 'Area = (3√3 / 2) × s²  |  Perimeter = 6s';
        break;
      }

      case 'ellipse': {
        const a = shape.radiusX;
        const b = shape.radiusY;
        const area = Math.PI * a * b;

        const h = Math.pow(a - b, 2) / Math.pow(a + b, 2);
        const circumference = Math.PI * (a + b) * (1 + (3 * h) / (10 + Math.sqrt(4 - 3 * h)));
        const major = Math.max(a, b);
        const minor = Math.min(a, b);
        const eccentricity = Math.sqrt(1 - (minor * minor) / (major * major));

        rows = [
          { label: 'Radius X (a):', value: `${formatMetric(a)} units` },
          { label: 'Radius Y (b):', value: `${formatMetric(b)} units` },
          { label: 'Area:', value: `${formatMetric(area)} sq units` },
          { label: 'Circumference:', value: `${formatMetric(circumference)} units` },
          { label: 'Eccentricity (e):', value: formatMetric(eccentricity) }
        ];
        formulaText = 'Area = π · a · b  |  Eccentricity = √(1 - b²/a²)';
        break;
      }
    }
  }

  body.innerHTML = `
    ${rows.map(r => `
      <div class="prop-metric-row">
        <span class="prop-metric-label">${r.label}</span>
        <span class="prop-metric-value">${r.value}</span>
      </div>
    `).join('')}
    <div class="prop-formula-card">
      ${formulaText}
    </div>
  `;
}

function formatMetric(val) {
  if (isNaN(val)) return '—';
  // If whole integer, show integer, else 2 decimal places
  if (Math.abs(val - Math.round(val)) < 1e-4) {
    return String(Math.round(val));
  }
  return val.toFixed(2);
}

// --- HASH ROUTING (Routing Between Home and Dedicated Laboratories) ---
function initHashRouting() {
  window.addEventListener('hashchange', handleRouteChange);
  handleRouteChange();
}

function handleRouteChange() {
  const rawHash = (window.location.hash || '').replace(/^#/, '').toLowerCase().trim();
  const homeView = document.getElementById('homeView');
  const labView = document.getElementById('labView');
  const geometryWorkspace = document.getElementById('geometryWorkspace');
  const placeholderWorkspace = document.getElementById('placeholderWorkspace');
  const labPageTitle = document.getElementById('labPageTitle');
  const labBadge = document.getElementById('labBadge');
  const labSubjectSubtitle = document.getElementById('labSubjectSubtitle');

  // Route to Home View
  if (!rawHash || rawHash === 'home' || (!LABS_CONFIG[rawHash] && rawHash !== 'geometry')) {
    document.body.classList.remove('geometry-mode');
    if (homeView) homeView.classList.add('active');
    if (labView) labView.classList.remove('active');
    if (currentViewMode === '3d') {
      disposeThreeScene();
    }
    window.scrollTo({ top: 0, behavior: 'instant' });
    return;
  }

  // Switch to Lab View
  if (homeView) homeView.classList.remove('active');
  if (labView) labView.classList.add('active');

  if (rawHash === 'geometry') {
    // Enable Full-Screen Desmos-like geometry mode
    document.body.classList.add('geometry-mode');
    if (geometryWorkspace) geometryWorkspace.classList.add('active');
    if (placeholderWorkspace) placeholderWorkspace.classList.remove('active');

    setTimeout(() => {
      if (currentViewMode === '3d') {
        initThreeScene();
        rebuildThreeShapes();
      } else {
        resizeCanvas();
        render();
      }
    }, 30);
  } else {
    // Non-Geometry Category Labs (Algebra, Trigonometry, etc.)
    document.body.classList.remove('geometry-mode');
    if (geometryWorkspace) geometryWorkspace.classList.remove('active');
    if (placeholderWorkspace) placeholderWorkspace.classList.add('active');
    if (currentViewMode === '3d') {
      disposeThreeScene();
    }

    const config = LABS_CONFIG[rawHash];
    if (config) {
      if (labPageTitle) labPageTitle.textContent = config.title;
      if (labBadge) labBadge.textContent = config.badge;
      if (labSubjectSubtitle) labSubjectSubtitle.textContent = config.subtitle;
      renderPlaceholderLab(config);
    }
  }

  window.scrollTo({ top: 0, behavior: 'instant' });
}

function renderPlaceholderLab(config) {
  const heading = document.getElementById('constructionHeading');
  const desc = document.getElementById('constructionDesc');
  const iconBubble = document.getElementById('constructionIconBubble');
  const iconChar = document.getElementById('constructionIconChar');
  const tag = document.getElementById('constructionTag');
  const artBg = document.getElementById('placeholderArtBg');
  const modulesList = document.getElementById('upcomingModulesList');
  const modulesTitle = document.getElementById('placeholderModulesTitle');

  if (heading) heading.textContent = 'This lab is under construction. Check back soon!';
  if (desc) desc.textContent = config.desc;
  if (iconChar) iconChar.textContent = config.icon;
  if (tag) tag.textContent = `${config.title} Laboratory`;
  if (modulesTitle) modulesTitle.textContent = `${config.title} Modules`;

  if (artBg && config.bgSvg) {
    artBg.innerHTML = config.bgSvg;
  }

  if (iconBubble && config.themeColor) {
    iconBubble.style.borderColor = config.themeColor;
    iconBubble.style.color = config.themeColor;
  }

  if (modulesList && config.modules) {
    modulesList.innerHTML = config.modules.map(mod => `
      <div class="upcoming-module-item">
        <div class="module-item-header">
          <span class="module-item-name">${mod.name}</span>
          <span class="module-status-badge">${mod.status}</span>
        </div>
        <p class="module-item-desc">${mod.desc}</p>
      </div>
    `).join('');
  }
}
